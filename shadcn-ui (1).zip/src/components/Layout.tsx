import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import { ScrollArea } from './ui/scroll-area';

const Layout = () => {
  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <main className="container p-6 max-w-7xl">
            <Outlet />
          </main>
        </ScrollArea>
      </div>
    </div>
  );
};

export default Layout;