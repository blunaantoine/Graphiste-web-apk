import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/button';
import { PlusCircle, LayoutDashboard, Moon, Sun, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTheme } from './theme-provider';

const Sidebar = () => {
  const { pathname } = useLocation();
  const { theme, setTheme } = useTheme();

  return (
    <div className="w-64 h-screen border-r border-border bg-sidebar-background text-sidebar-foreground flex flex-col">
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border">
        <h1 className="text-xl font-bold">GraphiTask</h1>
        <p className="text-sm text-sidebar-foreground/70">Gestion de projets graphiques</p>
      </div>

      {/* Navigation */}
      <div className="flex-1 py-4">
        <nav className="space-y-1 px-2">
          <Link to="/">
            <Button 
              variant={pathname === '/' ? 'secondary' : 'ghost'} 
              className={cn(
                "w-full justify-start",
                pathname === '/' && "bg-sidebar-accent text-sidebar-accent-foreground"
              )}
            >
              <LayoutDashboard className="mr-2 h-4 w-4" />
              Tableau de bord
              {pathname === '/' && <ChevronRight className="ml-auto h-4 w-4" />}
            </Button>
          </Link>
          <Link to="/new">
            <Button 
              variant={pathname === '/new' ? 'secondary' : 'ghost'} 
              className={cn(
                "w-full justify-start",
                pathname === '/new' && "bg-sidebar-accent text-sidebar-accent-foreground"
              )}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Nouvelle tâche
              {pathname === '/new' && <ChevronRight className="ml-auto h-4 w-4" />}
            </Button>
          </Link>
        </nav>
      </div>
      
      {/* Toggle theme */}
      <div className="border-t border-sidebar-border p-4">
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full justify-start"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        >
          {theme === 'dark' ? (
            <>
              <Sun className="mr-2 h-4 w-4" />
              Mode clair
            </>
          ) : (
            <>
              <Moon className="mr-2 h-4 w-4" />
              Mode sombre
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;