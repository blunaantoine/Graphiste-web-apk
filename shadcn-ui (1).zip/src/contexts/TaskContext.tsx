import React, { createContext, useContext, useEffect, useState } from 'react';

// Définition des types
export type TaskType = 'logo' | 'flyer' | 'carte' | 'etiquette' | 'brochure' | 'affiche' | 'autre';
export type TaskStatus = 'En attente' | 'En cours' | 'Terminé';

export interface Task {
  id: string;
  nom: string;
  type: TaskType;
  client: string;
  prix: number;
  debut: string; // Format ISO date string
  fin: string; // Format ISO date string
  statut: TaskStatus;
  progression: number; // 0-100
  notes?: string;
  dateCreation: string; // Format ISO date string
  dateModification: string; // Format ISO date string
}

interface TaskContextType {
  tasks: Task[];
  addTask: (task: Omit<Task, 'id' | 'dateCreation' | 'dateModification'>) => void;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  getTaskById: (id: string) => Task | undefined;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export const useTaskContext = () => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error("useTaskContext doit être utilisé à l'intérieur d'un TaskProvider");
  }
  return context;
};

interface TaskProviderProps {
  children: React.ReactNode;
}

export const TaskProvider: React.FC<TaskProviderProps> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);

  // Charger les tâches depuis le localStorage au démarrage
  useEffect(() => {
    const storedTasks = localStorage.getItem('graphitask-tasks');
    if (storedTasks) {
      try {
        setTasks(JSON.parse(storedTasks));
      } catch (error) {
        console.error('Erreur lors du chargement des tâches:', error);
        // Si erreur, initialiser avec un tableau vide
        setTasks([]);
      }
    }
  }, []);

  // Sauvegarder les tâches dans le localStorage à chaque modification
  useEffect(() => {
    localStorage.setItem('graphitask-tasks', JSON.stringify(tasks));
  }, [tasks]);

  // Ajouter une nouvelle tâche
  const addTask = (newTask: Omit<Task, 'id' | 'dateCreation' | 'dateModification'>) => {
    const now = new Date().toISOString();
    const task: Task = {
      ...newTask,
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      dateCreation: now,
      dateModification: now,
    };
    setTasks((prev) => [...prev, task]);
  };

  // Mettre à jour une tâche existante
  const updateTask = (id: string, updatedTask: Partial<Task>) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id === id) {
          return {
            ...task,
            ...updatedTask,
            dateModification: new Date().toISOString(),
          };
        }
        return task;
      })
    );
  };

  // Supprimer une tâche
  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
  };

  // Récupérer une tâche par son ID
  const getTaskById = (id: string) => {
    return tasks.find((task) => task.id === id);
  };

  // Exemple de données par défaut pour démonstration
  useEffect(() => {
    // Ajouter une tâche d'exemple si aucune tâche n'existe
    if (tasks.length === 0) {
      const exampleTask: Omit<Task, 'id' | 'dateCreation' | 'dateModification'> = {
        nom: 'Affiche événement TogoTech',
        type: 'affiche',
        client: 'Mme Akouvi',
        prix: 15000,
        debut: '2025-07-17T10:00:00.000Z',
        fin: '2025-07-18T16:00:00.000Z',
        statut: 'En cours',
        progression: 40,
        notes: 'Besoin d\'inclure les logos des sponsors.'
      };
      addTask(exampleTask);
    }
  }, []); // Exécuter uniquement au montage initial

  const value = {
    tasks,
    addTask,
    updateTask,
    deleteTask,
    getTaskById,
  };

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
};