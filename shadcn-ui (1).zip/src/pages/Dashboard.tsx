import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  PlusCircle, 
  Search, 
  Edit,
  Trash2, 
  Filter,
  ArrowUpDown,
  CheckCircle2,
  Clock,
  HourglassIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { useTaskContext, Task, TaskStatus, TaskType } from '../contexts/TaskContext';

// Composant pour afficher le statut d'une tâche
const StatusBadge = ({ status }: { status: TaskStatus }) => {
  switch (status) {
    case 'En attente':
      return (
        <Badge variant="outline" className="status-pending">
          <HourglassIcon className="mr-1 h-3 w-3" />
          En attente
        </Badge>
      );
    case 'En cours':
      return (
        <Badge variant="outline" className="status-in-progress">
          <Clock className="mr-1 h-3 w-3" />
          En cours
        </Badge>
      );
    case 'Terminé':
      return (
        <Badge variant="outline" className="status-completed">
          <CheckCircle2 className="mr-1 h-3 w-3" />
          Terminé
        </Badge>
      );
    default:
      return null;
  }
};

// Icônes pour les types de projets
const getTaskTypeIcon = (type: TaskType) => {
  switch (type) {
    case 'logo':
      return '🎨';
    case 'flyer':
      return '📃';
    case 'carte':
      return '📇';
    case 'etiquette':
      return '🏷️';
    case 'brochure':
      return '📁';
    case 'affiche':
      return '🖼️';
    default:
      return '📄';
  }
};

const Dashboard = () => {
  const navigate = useNavigate();
  const { tasks, deleteTask } = useTaskContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<TaskStatus | 'Tous'>('Tous');
  const [filterType, setFilterType] = useState<TaskType | 'Tous'>('Tous');
  const [sortBy, setSortBy] = useState<'date' | 'nom' | 'statut'>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);

  // Appliquer les filtres et la recherche aux tâches
  const filteredTasks = useMemo(() => {
    return tasks
      .filter((task) => {
        // Filtrage par recherche (nom et client)
        const searchMatch = 
          task.nom.toLowerCase().includes(searchTerm.toLowerCase()) || 
          task.client.toLowerCase().includes(searchTerm.toLowerCase());
        
        // Filtrage par statut
        const statusMatch = filterStatus === 'Tous' ? true : task.statut === filterStatus;
        
        // Filtrage par type
        const typeMatch = filterType === 'Tous' ? true : task.type === filterType;
        
        return searchMatch && statusMatch && typeMatch;
      })
      .sort((a, b) => {
        // Tri des tâches
        if (sortBy === 'date') {
          return sortDirection === 'desc'
            ? new Date(b.debut).getTime() - new Date(a.debut).getTime()
            : new Date(a.debut).getTime() - new Date(b.debut).getTime();
        }
        
        if (sortBy === 'nom') {
          return sortDirection === 'desc'
            ? b.nom.localeCompare(a.nom)
            : a.nom.localeCompare(b.nom);
        }
        
        if (sortBy === 'statut') {
          const statusPriority = { 'En cours': 0, 'En attente': 1, 'Terminé': 2 };
          return sortDirection === 'desc'
            ? statusPriority[b.statut] - statusPriority[a.statut]
            : statusPriority[a.statut] - statusPriority[b.statut];
        }
        
        return 0;
      });
  }, [tasks, searchTerm, filterStatus, filterType, sortBy, sortDirection]);
  
  // Fonction pour gérer le tri
  const handleSort = (key: 'date' | 'nom' | 'statut') => {
    if (sortBy === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(key);
      setSortDirection('desc');
    }
  };
  
  // Confirmer la suppression d'une tâche
  const confirmDelete = (taskId: string) => {
    setTaskToDelete(taskId);
    setDeleteDialogOpen(true);
  };
  
  // Supprimer une tâche après confirmation
  const handleDeleteConfirm = () => {
    if (taskToDelete) {
      deleteTask(taskToDelete);
      setTaskToDelete(null);
      setDeleteDialogOpen(false);
    }
  };

  // Formater le montant en FCFA
  const formatPrix = (prix: number) => {
    return prix.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ' FCFA';
  };
  
  // Formater les dates
  const formatDate = (isoDate: string) => {
    const date = new Date(isoDate);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tableau de bord</h1>
          <p className="text-muted-foreground">
            Gérez vos projets graphiques et suivez leur progression.
          </p>
        </div>
        <Button onClick={() => navigate('/new')} className="sm:w-auto">
          <PlusCircle className="mr-2 h-4 w-4" />
          Nouvelle tâche
        </Button>
      </div>
      
      {/* Filtres et recherche */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Rechercher par nom ou client..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                Statut: {filterStatus}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuGroup>
                <DropdownMenuItem onClick={() => setFilterStatus('Tous')}>
                  Tous
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterStatus('En attente')}>
                  En attente
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterStatus('En cours')}>
                  En cours
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterStatus('Terminé')}>
                  Terminé
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                Type: {filterType}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuGroup>
                <DropdownMenuItem onClick={() => setFilterType('Tous')}>
                  Tous
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('logo')}>
                  Logo
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('flyer')}>
                  Flyer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('carte')}>
                  Carte
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('etiquette')}>
                  Étiquette
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('brochure')}>
                  Brochure
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('affiche')}>
                  Affiche
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('autre')}>
                  Autre
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center">
                <ArrowUpDown className="mr-2 h-4 w-4" />
                Trier
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuLabel>Trier par</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuGroup>
                <DropdownMenuItem onClick={() => handleSort('date')}>
                  Date {sortBy === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSort('nom')}>
                  Nom {sortBy === 'nom' && (sortDirection === 'asc' ? '↑' : '↓')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSort('statut')}>
                  Statut {sortBy === 'statut' && (sortDirection === 'asc' ? '↑' : '↓')}
                </DropdownMenuItem>
              </DropdownMenuGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Liste des tâches */}
      {filteredTasks.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="text-7xl mb-4">🎨</div>
          <h3 className="text-xl font-semibold mb-1">Aucune tâche trouvée</h3>
          <p className="text-muted-foreground mb-4">
            {tasks.length === 0 
              ? "Vous n'avez pas encore créé de tâches." 
              : "Aucune tâche ne correspond à vos critères de recherche."}
          </p>
          <Button onClick={() => navigate('/new')}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Ajouter une tâche
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTasks.map((task) => (
            <Card key={task.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <CardTitle className="flex items-center">
                      <span className="mr-2">{getTaskTypeIcon(task.type)}</span>
                      {task.nom}
                    </CardTitle>
                    <CardDescription>Client: {task.client}</CardDescription>
                  </div>
                  <StatusBadge status={task.statut} />
                </div>
              </CardHeader>
              <CardContent className="pb-3 space-y-3">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Prix</div>
                  <div className="font-medium">{formatPrix(task.prix)}</div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Début</div>
                    <div className="font-medium">{formatDate(task.debut)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Fin prévue</div>
                    <div className="font-medium">{formatDate(task.fin)}</div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center text-sm mb-1">
                    <span className="text-muted-foreground">Progression</span>
                    <span className="font-medium">{task.progression}%</span>
                  </div>
                  <Progress value={task.progression} className="h-2" />
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex justify-between w-full">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate(`/edit/${task.id}`)}
                  >
                    <Edit className="mr-2 h-4 w-4" />
                    Modifier
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => confirmDelete(task.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Supprimer
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      
      {/* Dialog de confirmation de suppression */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette tâche ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Annuler
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm}>
              Supprimer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dashboard;